package com.example.data.repository

import com.example.data.db.BankCardDao
import com.example.data.db.BankSenderDao
import com.example.data.db.TransactionDao
import com.example.data.model.BankCardEntity
import com.example.data.model.BankSenderEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.util.PersianUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class FinanceRepository(
    private val transactionDao: TransactionDao,
    private val bankCardDao: BankCardDao,
    private val bankSenderDao: BankSenderDao
) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allCards: Flow<List<BankCardEntity>> = bankCardDao.getAllCards()
    val allSenders: Flow<List<BankSenderEntity>> = bankSenderDao.getAllSenders()
    val totalCardsBalance: Flow<Long?> = bankCardDao.getTotalCardsBalance()
    val totalExpense: Flow<Long?> = transactionDao.getTotalExpense()
    val totalIncome: Flow<Long?> = transactionDao.getTotalIncome()

    suspend fun insertTransaction(transaction: TransactionEntity): Long {
        val id = transactionDao.insert(transaction)

        // Update card balance automatically if card found
        if (transaction.cardLast4.isNotEmpty()) {
            val card = bankCardDao.getCardByLast4(transaction.cardLast4)
            if (card != null) {
                if (transaction.balanceAfter != null && transaction.balanceAfter > 0) {
                    bankCardDao.updateBalanceByCardLast4(transaction.cardLast4, transaction.balanceAfter)
                } else {
                    val delta = when (transaction.type) {
                        TransactionType.INCOME -> transaction.amount
                        TransactionType.EXPENSE, TransactionType.TRANSFER -> -transaction.amount
                    }
                    bankCardDao.adjustBalance(transaction.cardLast4, delta)
                }
            }
        }
        return id
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        transactionDao.delete(transaction)

        // Revert card balance adjustment
        if (transaction.cardLast4.isNotEmpty()) {
            val card = bankCardDao.getCardByLast4(transaction.cardLast4)
            if (card != null) {
                val delta = when (transaction.type) {
                    TransactionType.INCOME -> -transaction.amount
                    TransactionType.EXPENSE, TransactionType.TRANSFER -> transaction.amount
                }
                bankCardDao.adjustBalance(transaction.cardLast4, delta)
            }
        }
    }

    suspend fun insertCard(card: BankCardEntity): Long = bankCardDao.insert(card)
    suspend fun updateCard(card: BankCardEntity) = bankCardDao.update(card)
    suspend fun deleteCard(id: Long) = bankCardDao.deleteById(id)

    suspend fun insertSender(sender: BankSenderEntity): Long = bankSenderDao.insert(sender)
    suspend fun updateSender(sender: BankSenderEntity) = bankSenderDao.update(sender)
    suspend fun deleteSender(id: Long) = bankSenderDao.deleteById(id)

    suspend fun isSmsAlreadyProcessed(rawSms: String): Boolean {
        return transactionDao.findByRawSms(rawSms) != null
    }

    suspend fun seedDefaultsIfEmpty() {
        val currentCards = allCards.first()
        if (currentCards.isEmpty()) {
            // Seed 2 default cards
            bankCardDao.insert(
                BankCardEntity(
                    bankName = "بانک سامان",
                    cardLast4 = "5859",
                    cardHolder = "کارت اصلی",
                    balance = 14500000L,
                    colorHex = 0xFF0D9488, // Teal
                    smsSenderNumber = "9820004000"
                )
            )
            bankCardDao.insert(
                BankCardEntity(
                    bankName = "بانک ملت",
                    cardLast4 = "6104",
                    cardHolder = "حقوق و خرج روزمره",
                    balance = 8200000L,
                    colorHex = 0xFFDC2626, // Red
                    smsSenderNumber = "20004000"
                )
            )
            bankCardDao.insert(
                BankCardEntity(
                    bankName = "بلو بانک",
                    cardLast4 = "6219",
                    cardHolder = "کارت خرید آنلاین",
                    balance = 3450000L,
                    colorHex = 0xFF2563EB, // Royal Blue
                    smsSenderNumber = "BluBank"
                )
            )

            // Seed default bank sender numbers known in Iran
            val defaultSenders = listOf(
                BankSenderEntity(senderNumber = "9820004000", bankName = "بانک سامان", associatedCardLast4 = "5859"),
                BankSenderEntity(senderNumber = "20004000", bankName = "بانک ملت", associatedCardLast4 = "6104"),
                BankSenderEntity(senderNumber = "BluBank", bankName = "بلو بانک", associatedCardLast4 = "6219"),
                BankSenderEntity(senderNumber = "+9820004000", bankName = "سامان پیامک"),
                BankSenderEntity(senderNumber = "BankMellat", bankName = "بانک ملت"),
                BankSenderEntity(senderNumber = "+989821", bankName = "بانک ملی ایران"),
                BankSenderEntity(senderNumber = "B.Melli", bankName = "بانک ملی ایران"),
                BankSenderEntity(senderNumber = "Pasargad", bankName = "بانک پاسارگاد"),
                BankSenderEntity(senderNumber = "BankTejarat", bankName = "بانک تجارت"),
                BankSenderEntity(senderNumber = "SaderatBank", bankName = "بانک صادرات"),
                BankSenderEntity(senderNumber = "Resalat", bankName = "بانک رسالت"),
                BankSenderEntity(senderNumber = "MehrIran", bankName = "بانک مهر ایران")
            )
            for (sender in defaultSenders) {
                bankSenderDao.insert(sender)
            }

            // Seed a few initial realistic transactions
            val now = System.currentTimeMillis()
            val dayMs = 86400000L
            val transactions = listOf(
                TransactionEntity(
                    title = "واریز حقوق ماهانه",
                    amount = 28000000L,
                    type = TransactionType.INCOME,
                    category = "حقوق و دستمزد",
                    bankName = "بانک ملت",
                    cardLast4 = "6104",
                    balanceAfter = 36200000L,
                    timestamp = now - dayMs * 3,
                    dateStr = PersianUtils.timestampToPersianDate(now - dayMs * 3),
                    trackingCode = "89127361",
                    note = "واریز حقوق شرکت"
                ),
                TransactionEntity(
                    title = "خرید سوپرمارکت افق کوروش",
                    amount = 1450000L,
                    type = TransactionType.EXPENSE,
                    category = "سوپرمارکت",
                    bankName = "بانک سامان",
                    cardLast4 = "5859",
                    balanceAfter = 14500000L,
                    timestamp = now - dayMs * 2,
                    dateStr = PersianUtils.timestampToPersianDate(now - dayMs * 2),
                    trackingCode = "45129831",
                    note = "خرید مواد غذایی هفتگی"
                ),
                TransactionEntity(
                    title = "کرایه اسنپ",
                    amount = 85000L,
                    type = TransactionType.EXPENSE,
                    category = "حمل و نقل",
                    bankName = "بلو بانک",
                    cardLast4 = "6219",
                    balanceAfter = 3450000L,
                    timestamp = now - dayMs,
                    dateStr = PersianUtils.timestampToPersianDate(now - dayMs),
                    trackingCode = "10984321",
                    note = "اسنپ تا محل کار"
                ),
                TransactionEntity(
                    title = "خرید دارو و ویتامین",
                    amount = 620000L,
                    type = TransactionType.EXPENSE,
                    category = "پزشکی و سلامت",
                    bankName = "بانک سامان",
                    cardLast4 = "5859",
                    balanceAfter = 13880000L,
                    timestamp = now - 3600000L * 5,
                    dateStr = PersianUtils.timestampToPersianDate(now),
                    trackingCode = "77218390",
                    note = "داروخانه دکتر حسینی"
                )
            )
            for (t in transactions) {
                transactionDao.insert(t)
            }
        }
    }
}
