package com.example.data.db

import androidx.room.*
import com.example.data.model.BankCardEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BankCardDao {
    @Query("SELECT * FROM bank_cards ORDER BY id ASC")
    fun getAllCards(): Flow<List<BankCardEntity>>

    @Query("SELECT * FROM bank_cards WHERE cardLast4 = :cardLast4 LIMIT 1")
    suspend fun getCardByLast4(cardLast4: String): BankCardEntity?

    @Query("SELECT * FROM bank_cards WHERE id = :id LIMIT 1")
    suspend fun getCardById(id: Long): BankCardEntity?

    @Query("SELECT SUM(balance) FROM bank_cards")
    fun getTotalCardsBalance(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(card: BankCardEntity): Long

    @Update
    suspend fun update(card: BankCardEntity)

    @Delete
    suspend fun delete(card: BankCardEntity)

    @Query("DELETE FROM bank_cards WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE bank_cards SET balance = :newBalance WHERE cardLast4 = :cardLast4")
    suspend fun updateBalanceByCardLast4(cardLast4: String, newBalance: Long)

    @Query("UPDATE bank_cards SET balance = balance + :delta WHERE cardLast4 = :cardLast4")
    suspend fun adjustBalance(cardLast4: String, delta: Long)
}
