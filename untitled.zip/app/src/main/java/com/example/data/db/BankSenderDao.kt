package com.example.data.db

import androidx.room.*
import com.example.data.model.BankSenderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BankSenderDao {
    @Query("SELECT * FROM bank_senders ORDER BY id ASC")
    fun getAllSenders(): Flow<List<BankSenderEntity>>

    @Query("SELECT * FROM bank_senders WHERE isEnabled = 1")
    suspend fun getActiveSenders(): List<BankSenderEntity>

    @Query("SELECT * FROM bank_senders WHERE senderNumber = :number LIMIT 1")
    suspend fun findBySenderNumber(number: String): BankSenderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(sender: BankSenderEntity): Long

    @Update
    suspend fun update(sender: BankSenderEntity)

    @Delete
    suspend fun delete(sender: BankSenderEntity)

    @Query("DELETE FROM bank_senders WHERE id = :id")
    suspend fun deleteById(id: Long)
}
