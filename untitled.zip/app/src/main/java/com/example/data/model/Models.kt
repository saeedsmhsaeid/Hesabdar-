package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    EXPENSE,   // برداشت / هزینه
    INCOME,    // واریز / درآمد
    TRANSFER   // انتقال / جابجایی
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Long, // In Tomans
    val type: TransactionType,
    val category: String,
    val bankName: String,
    val cardLast4: String = "",
    val balanceAfter: Long? = null, // In Tomans
    val timestamp: Long = System.currentTimeMillis(),
    val dateStr: String = "", // Persian formatted date
    val trackingCode: String? = null,
    val rawSms: String? = null,
    val note: String = ""
)

@Entity(tableName = "bank_cards")
data class BankCardEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val bankName: String,
    val cardLast4: String,
    val cardHolder: String = "کاربر گرامی",
    val balance: Long = 0L, // In Tomans
    val colorHex: Long = 0xFF10B981,
    val smsSenderNumber: String = ""
)

@Entity(tableName = "bank_senders")
data class BankSenderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val senderNumber: String, // e.g. "9820004000", "+989821", "BankMellat", "0912..."
    val bankName: String,
    val associatedCardLast4: String = "",
    val isEnabled: Boolean = true
)

data class ParsedSmsResult(
    val isValidBankSms: Boolean,
    val type: TransactionType,
    val amountToman: Long,
    val cardLast4: String,
    val bankName: String,
    val balanceAfterToman: Long?,
    val trackingCode: String?,
    val suggestedCategory: String,
    val description: String,
    val rawSms: String
)
