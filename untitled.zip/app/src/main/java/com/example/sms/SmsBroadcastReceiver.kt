package com.example.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.example.SmartFinanceApp
import com.example.data.model.TransactionEntity
import com.example.util.PersianUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (messages.isNullOrEmpty()) return

            val fullBody = StringBuilder()
            var senderAddress = ""

            for (sms in messages) {
                if (senderAddress.isEmpty()) {
                    senderAddress = sms.displayOriginatingAddress ?: sms.originatingAddress ?: ""
                }
                fullBody.append(sms.displayMessageBody ?: sms.messageBody ?: "")
            }

            val smsText = fullBody.toString()
            if (smsText.isBlank()) return

            val parsed = PersianBankSmsParser.parse(smsText, senderAddress)
            if (parsed.isValidBankSms && parsed.amountToman > 0) {
                // Insert into Database asynchronously
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val repository = SmartFinanceApp.instance.repository
                        val alreadyExists = repository.isSmsAlreadyProcessed(smsText)
                        if (!alreadyExists) {
                            val now = System.currentTimeMillis()
                            val transaction = TransactionEntity(
                                title = parsed.description,
                                amount = parsed.amountToman,
                                type = parsed.type,
                                category = parsed.suggestedCategory,
                                bankName = parsed.bankName,
                                cardLast4 = parsed.cardLast4,
                                balanceAfter = parsed.balanceAfterToman,
                                timestamp = now,
                                dateStr = PersianUtils.timestampToPersianDate(now),
                                trackingCode = parsed.trackingCode,
                                rawSms = smsText,
                                note = "ثبت خودکار از پیامک بانک"
                            )
                            repository.insertTransaction(transaction)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    } finally {
                        pendingResult.finish()
                    }
                }
            }
        }
    }
}
