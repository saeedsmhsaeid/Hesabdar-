package com.example.sms

import com.example.data.model.ParsedSmsResult
import com.example.data.model.TransactionType
import com.example.util.PersianUtils

object PersianBankSmsParser {

    private val BANK_NAMES = listOf(
        "بانک سامان" to listOf("سامان", "saman", "sb24"),
        "بانک ملت" to listOf("ملت", "mellat", "bankmellat"),
        "بانک ملی" to listOf("ملی", "melli", "bmi"),
        "بانک پاسارگاد" to listOf("پاسارگاد", "pasargad", "bpi"),
        "بانک صادرات" to listOf("صادرات", "saderat", "bsi"),
        "بانک تجارت" to listOf("تجارت", "tejarat"),
        "بانک سپه" to listOf("سپه", "sepah"),
        "بانک کشاورزی" to listOf("کشاورزی", "keshavarzi", "bki"),
        "بانک مسکن" to listOf("مسکن", "maskan"),
        "بانک پارسیان" to listOf("پارسیان", "parsian"),
        "بلو بانک" to listOf("بلو", "blubank", "blu"),
        "بانک رسالت" to listOf("رسالت", "resalat"),
        "بانک مهر ایران" to listOf("مهر ایران", "قرض الحسنه مهر", "qmb"),
        "بانک رفاه" to listOf("رفاه", "refah"),
        "بانک آینده" to listOf("آینده", "ayandeh"),
        "بانک شهر" to listOf("شهر", "shahr"),
        "بانک خاورمیانه" to listOf("خاورمیانه", "mebank"),
        "بانک گردشگری" to listOf("گردشگری", "tourismbank"),
        "بانک دی" to listOf("دی", "daybank"),
        "بانک سینا" to listOf("سینا", "sinabank")
    )

    fun parse(smsBody: String, senderAddress: String = ""): ParsedSmsResult {
        val cleanBody = PersianUtils.toEnglishDigits(smsBody)
        val cleanSender = PersianUtils.toEnglishDigits(senderAddress).lowercase()

        // 1. Detect Bank
        var detectedBank = "بانک نامشخص"
        for ((bankName, keywords) in BANK_NAMES) {
            if (keywords.any { cleanSender.contains(it) || cleanBody.contains(it, ignoreCase = true) }) {
                detectedBank = bankName
                break
            }
        }

        // 2. Detect Transaction Type
        val lowerBody = cleanBody.lowercase()
        val isIncome = lowerBody.contains("واریز") ||
                lowerBody.contains("بستانکار") ||
                lowerBody.contains("پایا ورودی") ||
                lowerBody.contains("سود") ||
                (lowerBody.contains("دریافت") && !lowerBody.contains("برداشت"))

        val isExpense = lowerBody.contains("برداشت") ||
                lowerBody.contains("خرید") ||
                lowerBody.contains("بدهکار") ||
                lowerBody.contains("کسر") ||
                lowerBody.contains("پرداخت") ||
                lowerBody.contains("کارمزد") ||
                lowerBody.contains("پایا خروجی")

        val isTransfer = lowerBody.contains("کارت به کارت") ||
                lowerBody.contains("انتقال وجه") ||
                lowerBody.contains("انتقال به")

        val type = when {
            isTransfer && !isIncome -> TransactionType.TRANSFER
            isIncome && !isExpense -> TransactionType.INCOME
            isExpense -> TransactionType.EXPENSE
            else -> TransactionType.EXPENSE
        }

        // 3. Extract Amount
        val (amountToman, isRial) = extractAmount(cleanBody)

        // 4. Extract Balance (مانده)
        val balanceToman = extractBalance(cleanBody, isRial)

        // 5. Extract Card/Account last 4 digits
        val cardLast4 = extractCardLast4(cleanBody)

        // 6. Extract Tracking code
        val trackingCode = extractTrackingCode(cleanBody)

        // 7. Auto categorize
        val category = determineCategory(cleanBody, type)

        // 8. Extract Description/Merchant
        val description = extractMerchantOrTitle(cleanBody, type, category)

        val isValid = (amountToman > 0) && (isIncome || isExpense || isTransfer || cleanBody.contains("مانده") || cleanBody.contains("حساب"))

        return ParsedSmsResult(
            isValidBankSms = isValid,
            type = type,
            amountToman = amountToman,
            cardLast4 = cardLast4,
            bankName = detectedBank,
            balanceAfterToman = balanceToman,
            trackingCode = trackingCode,
            suggestedCategory = category,
            description = description,
            rawSms = smsBody
        )
    }

    private fun extractAmount(text: String): Pair<Long, Boolean> {
        // Pattern 1: مبلغ: 123,456 ریال / تومان
        val patternMablagh = Regex("""(?:مبلغ|مبلغ تراکنش|بهای خرید|مبلغ واریز|مبلغ برداشت)[:\s]+([0-9,]+)\s*(ریال|تومان|ت|R)?/?""", RegexOption.IGNORE_CASE)
        val match1 = patternMablagh.find(text)
        if (match1 != null) {
            val numStr = match1.groupValues[1].replace(",", "").trim()
            val unit = match1.groupValues.getOrNull(2)?.trim() ?: ""
            val rawNum = numStr.toLongOrNull() ?: 0L
            val isRial = unit.contains("ریال", ignoreCase = true) || unit.contains("r", ignoreCase = true) || (unit.isEmpty() && rawNum > 99999)
            val toman = if (isRial && rawNum >= 10) rawNum / 10 else rawNum
            return Pair(toman, isRial)
        }

        // Pattern 2: [0-9,]+ (ریال|تومان)
        val patternUnit = Regex("""([0-9,]{4,})\s*(ریال|تومان)""", RegexOption.IGNORE_CASE)
        val match2 = patternUnit.find(text)
        if (match2 != null) {
            val numStr = match2.groupValues[1].replace(",", "").trim()
            val unit = match2.groupValues[2].trim()
            val rawNum = numStr.toLongOrNull() ?: 0L
            val isRial = unit.contains("ریال", ignoreCase = true)
            val toman = if (isRial && rawNum >= 10) rawNum / 10 else rawNum
            return Pair(toman, isRial)
        }

        // Pattern 3: + or - followed by number
        val patternSign = Regex("""[+\-]\s*([0-9,]{3,})""")
        val match3 = patternSign.find(text)
        if (match3 != null) {
            val numStr = match3.groupValues[1].replace(",", "").trim()
            val rawNum = numStr.toLongOrNull() ?: 0L
            val isRial = rawNum > 99999
            val toman = if (isRial && rawNum >= 10) rawNum / 10 else rawNum
            return Pair(toman, isRial)
        }

        return Pair(0L, false)
    }

    private fun extractBalance(text: String, defaultIsRial: Boolean): Long? {
        val pattern = Regex("""(?:مانده|موجودی|مانده حساب|مانده کارت)[:\s]+([0-9,]+)\s*(ریال|تومان)?""", RegexOption.IGNORE_CASE)
        val match = pattern.find(text)
        if (match != null) {
            val numStr = match.groupValues[1].replace(",", "").trim()
            val unit = match.groupValues.getOrNull(2)?.trim() ?: ""
            val rawNum = numStr.toLongOrNull() ?: return null
            val isRial = if (unit.isNotEmpty()) unit.contains("ریال") else defaultIsRial || (rawNum > 99999)
            return if (isRial && rawNum >= 10) rawNum / 10 else rawNum
        }
        return null
    }

    private fun extractCardLast4(text: String): String {
        // First check for ...1234 or ***1234 or 5859...1234
        val patternDots = Regex("""(?:\.{2,4}|\*{2,4})([0-9]{4})""")
        val matchDots = patternDots.find(text)
        if (matchDots != null) {
            return matchDots.groupValues[1]
        }

        // e.g. کارت 1234 or حساب 1234
        val pattern1 = Regex("""(?:کارت|حساب|کارت:|حساب:)\s*(?:[0-9*.]*?)([0-9]{4})(?:[^\d]|$)""")
        val match1 = pattern1.find(text)
        if (match1 != null) {
            return match1.groupValues[1]
        }

        return ""
    }

    private fun extractTrackingCode(text: String): String? {
        val pattern = Regex("""(?:پیگیری|رهگیری|مرجع|کد پیگیری|شماره پیگیری)[:\s]+([0-9a-zA-Z]+)""")
        val match = pattern.find(text)
        return match?.groupValues?.get(1)?.trim()
    }

    fun determineCategory(text: String, type: TransactionType): String {
        val lower = text.lowercase()

        // Income specific
        if (type == TransactionType.INCOME) {
            if (lower.contains("حقوق") || lower.contains("دستمزد") || lower.contains("مساعده") || lower.contains("پاداش")) {
                return "حقوق و دستمزد"
            }
            if (lower.contains("سود") || lower.contains("سپرده")) {
                return "سود بانکی"
            }
            if (lower.contains("انتقال") || lower.contains("کارت به کارت") || lower.contains("پایا")) {
                return "انتقال وجه"
            }
            return "سایر درآمدها"
        }

        // Expenses
        if (lower.contains("اسنپ") || lower.contains("تپسی") || lower.contains("ماکسیم") ||
            lower.contains("بنزین") || lower.contains("جایگاه") || lower.contains("کرایه") ||
            lower.contains("مترو") || lower.contains("اتوبوس") || lower.contains("تاکسی")
        ) {
            return "حمل و نقل"
        }

        if (lower.contains("فروشگاه") || lower.contains("سوپر") || lower.contains("هایپر") ||
            lower.contains("کوروش") || lower.contains("افق") || lower.contains("جانبو") ||
            lower.contains("اتکا") || lower.contains("میوه") || lower.contains("نانوایی") ||
            lower.contains("لبنیات") || lower.contains("پروتئین") || lower.contains("گوشت")
        ) {
            return "سوپرمارکت"
        }

        if (lower.contains("رستوران") || lower.contains("کافه") || lower.contains("فست فود") ||
            lower.contains("پیتزا") || lower.contains("قهوه") || lower.contains("ساندویچ") ||
            lower.contains("شیرینی") || lower.contains("قنادی") || lower.contains("غذا")
        ) {
            return "خوراک و رستوران"
        }

        if (lower.contains("دیجیکالا") || lower.contains("دیجی کالا") || lower.contains("پوشاک") ||
            lower.contains("لباس") || lower.contains("کفش") || lower.contains("کیف") ||
            lower.contains("بوتیک") || lower.contains("آنلاین")
        ) {
            return "خرید و پوشاک"
        }

        if (lower.contains("داروخانه") || lower.contains("بیمارستان") || lower.contains("درمانگاه") ||
            lower.contains("کلینیک") || lower.contains("پزشک") || lower.contains("دکتر") ||
            lower.contains("دندانپزشک") || lower.contains("آزمایشگاه") || lower.contains("سونوگرافی")
        ) {
            return "پزشکی و سلامت"
        }

        if (lower.contains("قبض") || lower.contains("شارژ") || lower.contains("همراه اول") ||
            lower.contains("ایرانسل") || lower.contains("رایتل") || lower.contains("مخابرات") ||
            lower.contains("برق") || lower.contains("گاز") || lower.contains("آب") ||
            lower.contains("اینترنت") || lower.contains("بسته")
        ) {
            return "قبض و ارتباطات"
        }

        if (lower.contains("وام") || lower.contains("قسط") || lower.contains("اقساط")) {
            return "اقساط و وام"
        }

        if (lower.contains("کارت به کارت") || lower.contains("انتقال") || lower.contains("پایا") || lower.contains("ساتنا")) {
            return "انتقال وجه"
        }

        return "سایر هزینه‌ها"
    }

    private fun extractMerchantOrTitle(text: String, type: TransactionType, category: String): String {
        // Check for merchant patterns like "فروشگاه ...", "پذیرنده: ...", "خرید از ..."
        val pattern = Regex("""(?:خرید از|پذیرنده:|ترمینال:|فروشگاه|به نام)\s*([^\n\r,:]+)""")
        val match = pattern.find(text)
        if (match != null) {
            val merchant = match.groupValues[1].trim()
            if (merchant.isNotEmpty() && merchant.length > 2) {
                return merchant.take(30)
            }
        }

        return when (type) {
            TransactionType.INCOME -> "واریز ($category)"
            TransactionType.EXPENSE -> "برداشت ($category)"
            TransactionType.TRANSFER -> "انتقال وجه"
        }
    }
}
