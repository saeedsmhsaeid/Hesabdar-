package com.example.sms

import android.content.Context
import android.net.Uri
import com.example.data.model.TransactionEntity
import com.example.data.repository.FinanceRepository
import com.example.util.PersianUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SmsInboxHelper {

    suspend fun scanAndImportBankSms(
        context: Context,
        repository: FinanceRepository,
        limit: Int = 100
    ): Int = withContext(Dispatchers.IO) {
        var importedCount = 0
        val uri = Uri.parse("content://sms/inbox")
        val projection = arrayOf("_id", "address", "body", "date")

        try {
            val cursor = context.contentResolver.query(
                uri,
                projection,
                null,
                null,
                "date DESC"
            )

            cursor?.use {
                val addressIndex = it.getColumnIndexOrThrow("address")
                val bodyIndex = it.getColumnIndexOrThrow("body")
                val dateIndex = it.getColumnIndexOrThrow("date")

                var checked = 0
                while (it.moveToNext() && checked < limit) {
                    checked++
                    val address = it.getString(addressIndex) ?: ""
                    val body = it.getString(bodyIndex) ?: ""
                    val dateLong = it.getLong(dateIndex)

                    val parsed = PersianBankSmsParser.parse(body, address)
                    if (parsed.isValidBankSms && parsed.amountToman > 0) {
                        val alreadyProcessed = repository.isSmsAlreadyProcessed(body)
                        if (!alreadyProcessed) {
                            val transaction = TransactionEntity(
                                title = parsed.description,
                                amount = parsed.amountToman,
                                type = parsed.type,
                                category = parsed.suggestedCategory,
                                bankName = parsed.bankName,
                                cardLast4 = parsed.cardLast4,
                                balanceAfter = parsed.balanceAfterToman,
                                timestamp = if (dateLong > 0) dateLong else System.currentTimeMillis(),
                                dateStr = PersianUtils.timestampToPersianDate(if (dateLong > 0) dateLong else System.currentTimeMillis()),
                                trackingCode = parsed.trackingCode,
                                rawSms = body,
                                note = "وارد شده از صندوق پیامک"
                            )
                            repository.insertTransaction(transaction)
                            importedCount++
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        importedCount
    }
}
