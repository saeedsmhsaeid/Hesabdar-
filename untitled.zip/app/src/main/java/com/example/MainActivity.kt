package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AddCardDialog
import com.example.ui.components.AddTransactionDialog
import com.example.ui.screens.*
import com.example.ui.theme.SmartFinanceTheme
import com.example.ui.viewmodel.FinanceViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartFinanceTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: FinanceViewModel = viewModel()) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    var showAddTransactionDialog by remember { mutableStateOf(false) }
    var showAddCardDialog by remember { mutableStateOf(false) }

    val cards by viewModel.allCards.collectAsState()

    // SMS permission request on launch
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    LaunchedEffect(Unit) {
        val hasReceiveSms = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECEIVE_SMS
        ) == PackageManager.PERMISSION_GRANTED

        val hasReadSms = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasReceiveSms || !hasReadSms) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS
                )
            )
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_scaffold"),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حسابدار هوشمند",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showAddTransactionDialog = true },
                        modifier = Modifier.testTag("top_add_transaction_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "ثبت تراکنش",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = {
                        Icon(
                            if (selectedTab == 0) Icons.Filled.Dashboard else Icons.Outlined.Dashboard,
                            contentDescription = "داشبورد"
                        )
                    },
                    label = { Text("داشبورد", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_dashboard")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        Icon(
                            if (selectedTab == 1) Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong,
                            contentDescription = "تراکنش‌ها"
                        )
                    },
                    label = { Text("تراکنش‌ها", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_transactions")
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = {
                        Icon(
                            if (selectedTab == 2) Icons.Filled.BarChart else Icons.Outlined.BarChart,
                            contentDescription = "نمودارها"
                        )
                    },
                    label = { Text("تحلیل مالی", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_analytics")
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = {
                        Icon(
                            if (selectedTab == 3) Icons.Filled.CreditCard else Icons.Outlined.CreditCard,
                            contentDescription = "کارت‌ها"
                        )
                    },
                    label = { Text("کارت‌ها", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_cards")
                )

                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = {
                        Icon(
                            if (selectedTab == 4) Icons.Filled.Sms else Icons.Outlined.Sms,
                            contentDescription = "پیامک‌خوان"
                        )
                    },
                    label = { Text("پیامک‌خوان", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_sms_hub")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTab = { selectedTab = it },
                    onOpenAddTransaction = { showAddTransactionDialog = true },
                    onOpenAddCard = { showAddCardDialog = true }
                )
                1 -> TransactionsScreen(
                    viewModel = viewModel,
                    onOpenAddTransaction = { showAddTransactionDialog = true }
                )
                2 -> AnalyticsScreen(viewModel = viewModel)
                3 -> CardsScreen(
                    viewModel = viewModel,
                    onOpenAddCard = { showAddCardDialog = true }
                )
                4 -> SmsHubScreen(viewModel = viewModel)
            }
        }
    }

    if (showAddTransactionDialog) {
        AddTransactionDialog(
            cards = cards,
            onDismiss = { showAddTransactionDialog = false },
            onConfirm = { title, amount, type, category, bank, card4, note ->
                viewModel.addManualTransaction(title, amount, type, category, bank, card4, note)
                showAddTransactionDialog = false
            }
        )
    }

    if (showAddCardDialog) {
        AddCardDialog(
            onDismiss = { showAddCardDialog = false },
            onConfirm = { bank, card4, holder, balance, color ->
                viewModel.addCard(bank, card4, holder, balance, color)
                showAddCardDialog = false
            }
        )
    }
}
