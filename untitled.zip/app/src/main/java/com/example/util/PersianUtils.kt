package com.example.util

import java.text.DecimalFormat
import java.util.Calendar
import java.util.Locale

object PersianUtils {

    private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
    private val arabicDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    /**
     * Converts any Persian or Arabic numerals in string to standard Latin 0-9 digits.
     */
    fun toEnglishDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            when (ch) {
                in '۰'..'۹' -> sb.append((ch - '۰'))
                in '٠'..'٩' -> sb.append((ch - '٠'))
                '٫', '،' -> sb.append(',')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Converts English digits 0-9 to Persian digits ۰-۹.
     */
    fun toPersianDigits(input: String): String {
        val sb = StringBuilder()
        for (ch in input) {
            if (ch in '0'..'9') {
                sb.append(persianDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Formats amount in Tomans with thousands separators and optional currency unit.
     */
    fun formatToman(amount: Long, includeUnit: Boolean = true): String {
        val formatter = DecimalFormat("#,###")
        val formatted = formatter.format(amount)
        val persianFormatted = toPersianDigits(formatted)
        return if (includeUnit) "$persianFormatted تومان" else persianFormatted
    }

    /**
     * Converts gregorian timestamp to Persian (Solar Hijri) formatted string: yyyy/MM/dd
     */
    fun timestampToPersianDate(timestamp: Long): String {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = timestamp
        val gy = calendar.get(Calendar.YEAR)
        val gm = calendar.get(Calendar.MONTH) + 1
        val gd = calendar.get(Calendar.DAY_OF_MONTH)

        val (py, pm, pd) = gregorianToPersian(gy, gm, gd)
        val mStr = if (pm < 10) "0$pm" else "$pm"
        val dStr = if (pd < 10) "0$pd" else "$pd"
        return toPersianDigits("$py/$mStr/$dStr")
    }

    fun timestampToPersianTime(timestamp: Long): String {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = timestamp
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val hStr = if (hour < 10) "0$hour" else "$hour"
        val mStr = if (minute < 10) "0$minute" else "$minute"
        return toPersianDigits("$hStr:$mStr")
    }

    /**
     * Pure algorithm to convert Gregorian date to Persian Solar date.
     */
    fun gregorianToPersian(gYear: Int, gMonth: Int, gDay: Int): Triple<Int, Int, Int> {
        val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

        var gy = gYear - 1600
        var gm = gMonth - 1
        var gd = gDay - 1

        var gDayNo = 365 * gy + ((gy + 3) / 4) - ((gy + 99) / 100) + ((gy + 399) / 400)

        for (i in 0 until gm) {
            gDayNo += gDaysInMonth[i]
        }
        if (gm > 1 && ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0))) {
            gDayNo++
        }
        gDayNo += gd

        var jDayNo = gDayNo - 79

        val jNp = jDayNo / 12053
        jDayNo %= 12053

        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461

        if (jDayNo >= 366) {
            jy += ((jDayNo - 1) / 365)
            jDayNo = (jDayNo - 1) % 365
        }

        var jm = 0
        var jd = 0
        for (i in 0 until 11) {
            if (jDayNo < jDaysInMonth[i]) {
                jm = i + 1
                jd = jDayNo + 1
                break
            }
            jDayNo -= jDaysInMonth[i]
        }
        if (jm == 0) {
            jm = 12
            jd = jDayNo + 1
        }

        return Triple(jy, jm, jd)
    }
}
