package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val EmeraldLight = Color(0xFF6EE7B7)

val TealSecondary = Color(0xFF0D9488)
val TealDark = Color(0xFF115E59)

val ExpenseRed = Color(0xFFEF4444)
val ExpenseRedDark = Color(0xFF991B1B)
val IncomeGreen = Color(0xFF10B981)
val IncomeGreenDark = Color(0xFF065F46)
val TransferBlue = Color(0xFF3B82F6)

// Dark Palette
val DarkBackground = Color(0xFF0B1320)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF9FAFB)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Bank Card Preset Gradients/Colors
val CardColorTeal = 0xFF0D9488
val CardColorMellatRed = 0xFFDC2626
val CardColorBlu = 0xFF2563EB
val CardColorGold = 0xFFD97706
val CardColorPurple = 0xFF7C3AED
val CardColorSlate = 0xFF334155
