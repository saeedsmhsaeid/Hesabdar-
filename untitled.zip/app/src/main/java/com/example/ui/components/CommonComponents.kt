package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BankCardEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.theme.*
import com.example.util.PersianUtils

@Composable
fun TransactionItemCard(
    transaction: TransactionEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isExpense = transaction.type == TransactionType.EXPENSE || transaction.type == TransactionType.TRANSFER
    val iconColor = if (isExpense) ExpenseRed else IncomeGreen
    val amountPrefix = if (isExpense) "- " else "+ "

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("transaction_item_${transaction.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Right Side (RTL Start): Category Icon & Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getCategoryIcon(transaction.category, transaction.type),
                        contentDescription = transaction.category,
                        tint = iconColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = transaction.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                        ) {
                            Text(
                                text = transaction.category,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (transaction.cardLast4.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "کارت ${PersianUtils.toPersianDigits(transaction.cardLast4)}",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Left Side (RTL End): Amount & Date
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = amountPrefix + PersianUtils.formatToman(transaction.amount),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = iconColor
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = transaction.dateStr,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun BankCardView(
    card: BankCardEntity,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val baseColor = Color(card.colorHex)
    val gradientBrush = Brush.linearGradient(
        colors = listOf(
            baseColor,
            baseColor.copy(alpha = 0.75f),
            Color(0xFF0F172A)
        )
    )

    Card(
        modifier = modifier
            .width(280.dp)
            .height(165.dp)
            .clickable(onClick = onClick)
            .testTag("bank_card_${card.id}"),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(brush = gradientBrush)
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Row: Bank Name and Smart Chip Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = card.bankName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                    )

                    // Card Chip Symbol
                    Box(
                        modifier = Modifier
                            .size(32.dp, 24.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFFBBF24).copy(alpha = 0.85f))
                    )
                }

                // Middle: Card Number
                val maskedCard = "••••  ••••  ••••  ${PersianUtils.toPersianDigits(card.cardLast4)}"
                Text(
                    text = maskedCard,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 2.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 15.sp
                    )
                )

                // Bottom Row: Holder and Balance
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "دارنده کارت",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp
                            )
                        )
                        Text(
                            text = card.cardHolder,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "موجودی",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 10.sp
                            )
                        )
                        Text(
                            text = PersianUtils.formatToman(card.balance),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

fun getCategoryIcon(category: String, type: TransactionType): ImageVector {
    return when {
        category.contains("حقوق") -> Icons.Filled.Payments
        category.contains("سود") -> Icons.Filled.TrendingUp
        category.contains("خوراک") || category.contains("رستوران") -> Icons.Filled.Restaurant
        category.contains("سوپر") || category.contains("هایپر") -> Icons.Filled.ShoppingCart
        category.contains("حمل") || category.contains("اسنپ") -> Icons.Filled.DirectionsCar
        category.contains("خرید") || category.contains("پوشاک") -> Icons.Filled.ShoppingBag
        category.contains("پزشکی") || category.contains("سلامت") -> Icons.Filled.LocalHospital
        category.contains("قبض") || category.contains("ارتباط") -> Icons.Filled.ReceiptLong
        category.contains("انتقال") -> Icons.Filled.SwapHoriz
        category.contains("وام") || category.contains("قسط") -> Icons.Filled.AccountBalance
        type == TransactionType.INCOME -> Icons.Filled.ArrowDownward
        else -> Icons.Filled.ArrowUpward
    }
}
