package com.example.ui.screens

import android.Manifest
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BankSenderEntity
import com.example.data.model.ParsedSmsResult
import com.example.data.model.TransactionType
import com.example.ui.components.AddSenderDialog
import com.example.ui.components.getCategoryIcon
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinanceViewModel
import com.example.util.PersianUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmsHubScreen(viewModel: FinanceViewModel) {
    val context = LocalContext.current
    val senders by viewModel.allSenders.collectAsState()
    val testResult by viewModel.testSmsResult.collectAsState()
    val scanStatus by viewModel.scanStatusMessage.collectAsState()

    var customSmsInput by remember { mutableStateOf("") }
    var showAddSenderDialog by remember { mutableStateOf(false) }
    var senderToDelete by remember { mutableStateOf<BankSenderEntity?>(null) }
    var sampleSelected by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.READ_SMS] == true ||
                permissions[Manifest.permission.RECEIVE_SMS] == true
        if (granted) {
            viewModel.scanInbox(context)
        }
    }

    val sampleSmsList = listOf(
        "برداشت سامان" to "برداشت از کارت ۵۸۵۹...۱۲۳۴\nمبلغ: ۱,۵۰۰,۰۰۰ ریال\nمانده: ۱۲,۳۰۰,۰۰۰ ریال\nخرید از فروشگاه افق کوروش\nپیگیری: 87654321",
        "واریز حقوق ملت" to "واریز به حساب ...۶۱۰۴\nمبلغ: ۳۲,۰۰۰,۰۰۰ ریال\nمانده: ۴۵,۰۰۰,۰۰۰ ریال\nواریز حقوق و دستمزد\nساعت: ۱۴:۳۰",
        "اسنپ بلو" to "برداشت از حساب بلو\nمبلغ: ۶۵,۰۰۰ تومان\nمانده: ۲,۴۰۰,۰۰۰ تومان\nکرایه اسنپ\nکد پیگیری: ۹۸۲۳۷۴",
        "خرید دارو ملی" to "برداشت خرید\nکارت ۶۰۳۷...۴۵۱۲\nمبلغ: ۸۲۰,۰۰۰ ریال\nمانده: ۵,۲۰۰,۰۰۰ ریال\nداروخانه دکتر کریمی"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("sms_hub_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Intro Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(EmeraldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MarkChatRead,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "پیامک‌خوان هوشمند بانکی",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "با دریافت هر پیامک بانکی، دخل و خرج شما خودکار محاسبه، دسته‌بندی و روی کارت اعمال می‌شود.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // 2. Scan Inbox Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "اسکن پیامک‌های صندوق ورودی",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "خواندن پیامک‌های بانکی موجود در گوشی و ثبت خودکار",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.READ_SMS,
                                        Manifest.permission.RECEIVE_SMS
                                    )
                                )
                            },
                            modifier = Modifier.testTag("scan_inbox_button")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اسکن")
                        }
                    }

                    scanStatus?.let { msg ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldPrimary.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = msg, style = MaterialTheme.typography.bodySmall, color = EmeraldLight)
                            }
                        }
                    }
                }
            }
        }

        // 3. Interactive SMS Tester & Parser
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "تست و خواندن متن پیامک بانک",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "می‌توانید پیامک بانکی را اینجا جای‌گذاری (Paste) کنید تا موتور هوش مصنوعی اطلاعات آن را استخراج کند:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Samples Row
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(sampleSmsList) { (title, content) ->
                            SuggestionChip(
                                onClick = {
                                    sampleSelected = title
                                    customSmsInput = content
                                    viewModel.testParseSms(content)
                                },
                                label = { Text(title, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = customSmsInput,
                        onValueChange = {
                            customSmsInput = it
                            if (it.isBlank()) viewModel.clearTestSms()
                        },
                        label = { Text("متن پیامک بانکی را وارد کنید") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp)
                            .testTag("sms_input_box"),
                        maxLines = 5
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.testParseSms(customSmsInput) },
                            enabled = customSmsInput.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("analyze_sms_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تحلیل هوشمند پیامک")
                        }

                        if (customSmsInput.isNotEmpty()) {
                            OutlinedButton(
                                onClick = {
                                    customSmsInput = ""
                                    viewModel.clearTestSms()
                                }
                            ) {
                                Text("پاک کردن")
                            }
                        }
                    }

                    // Parsed Result Display
                    testResult?.let { res ->
                        AnimatedVisibility(visible = true) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("parsed_result_card"),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (res.isValidBankSms) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                                ),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = getCategoryIcon(res.suggestedCategory, res.type),
                                                contentDescription = null,
                                                tint = if (res.type == TransactionType.INCOME) IncomeGreen else ExpenseRed
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = if (res.type == TransactionType.INCOME) "واریز بانکی" else "برداشت / خرید",
                                                fontWeight = FontWeight.Bold,
                                                color = if (res.type == TransactionType.INCOME) IncomeGreen else ExpenseRed
                                            )
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Text(
                                                text = res.bankName,
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }

                                    HorizontalDivider()

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("مبلغ تراکنش:", style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            text = PersianUtils.formatToman(res.amountToman),
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                            color = if (res.type == TransactionType.INCOME) IncomeGreen else ExpenseRed
                                        )
                                    }

                                    if (res.cardLast4.isNotEmpty()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("شماره کارت/حساب:", style = MaterialTheme.typography.bodySmall)
                                            Text(PersianUtils.toPersianDigits("•••• ${res.cardLast4}"), fontWeight = FontWeight.Medium)
                                        }
                                    }

                                    if (res.balanceAfterToman != null) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("مانده حساب جدید:", style = MaterialTheme.typography.bodySmall)
                                            Text(PersianUtils.formatToman(res.balanceAfterToman), fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("دسته‌بندی خودکار:", style = MaterialTheme.typography.bodySmall)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = res.suggestedCategory,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    if (res.trackingCode != null) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("کد پیگیری:", style = MaterialTheme.typography.bodySmall)
                                            Text(PersianUtils.toPersianDigits(res.trackingCode), style = MaterialTheme.typography.bodySmall)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Button(
                                        onClick = {
                                            viewModel.commitParsedSms(res)
                                            customSmsInput = ""
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("commit_parsed_sms_button")
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("تأیید و ثبت در حسابداری")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Manage Registered Bank Sender Numbers (User feature: "هر شماره بانکی بدی")
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "سرشماره‌های بانکی تعریف شده",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "هدایت پیامک‌های این شماره‌ها به نرم‌افزار",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalButton(
                    onClick = { showAddSenderDialog = true },
                    modifier = Modifier.testTag("add_sender_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("افزودن سرشماره")
                }
            }
        }

        // 5. Senders List
        items(senders, key = { it.id }) { sender ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.ContactPhone, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = sender.bankName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                text = "شماره: ${sender.senderNumber}" + if (sender.associatedCardLast4.isNotEmpty()) " (کارت ${PersianUtils.toPersianDigits(sender.associatedCardLast4)})" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = { senderToDelete = sender }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف شماره", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (showAddSenderDialog) {
        AddSenderDialog(
            onDismiss = { showAddSenderDialog = false },
            onConfirm = { number, bank, card4 ->
                viewModel.addSender(number, bank, card4)
                showAddSenderDialog = false
            }
        )
    }

    senderToDelete?.let { sender ->
        AlertDialog(
            onDismissRequest = { senderToDelete = null },
            title = { Text("حذف سرشماره بانکی") },
            text = { Text("آیا از حذف سرشماره ${sender.senderNumber} (${sender.bankName}) اطمینان دارید؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSender(sender.id)
                        senderToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { senderToDelete = null }) { Text("انصراف") }
            }
        )
    }
}
