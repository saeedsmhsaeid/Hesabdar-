package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.SmartFinanceApp
import com.example.data.model.BankCardEntity
import com.example.data.model.BankSenderEntity
import com.example.data.model.ParsedSmsResult
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.FinanceRepository
import com.example.sms.PersianBankSmsParser
import com.example.sms.SmsInboxHelper
import com.example.util.PersianUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class FinanceViewModel(
    private val repository: FinanceRepository = SmartFinanceApp.instance.repository
) : ViewModel() {

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCards: StateFlow<List<BankCardEntity>> = repository.allCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSenders: StateFlow<List<BankSenderEntity>> = repository.allSenders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalBalance: StateFlow<Long> = repository.totalCardsBalance
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalIncome: StateFlow<Long> = repository.totalIncome
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalExpense: StateFlow<Long> = repository.totalExpense
        .map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Filters for transactions screen
    val searchQuery = MutableStateFlow("")
    val filterType = MutableStateFlow<TransactionType?>(null)
    val filterCategory = MutableStateFlow<String?>(null)

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        searchQuery,
        filterType,
        filterCategory
    ) { list, query, type, cat ->
        list.filter { item ->
            val matchQuery = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.category.contains(query, ignoreCase = true) ||
                    item.bankName.contains(query, ignoreCase = true) ||
                    item.cardLast4.contains(query) ||
                    (item.trackingCode?.contains(query) == true)
            val matchType = (type == null) || (item.type == type)
            val matchCategory = (cat == null) || (item.category == cat)
            matchQuery && matchType && matchCategory
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // SMS Tester State
    val testSmsResult = MutableStateFlow<ParsedSmsResult?>(null)
    val scanStatusMessage = MutableStateFlow<String?>(null)

    fun testParseSms(smsText: String, senderNumber: String = "") {
        if (smsText.isNotBlank()) {
            val result = PersianBankSmsParser.parse(smsText, senderNumber)
            testSmsResult.value = result
        } else {
            testSmsResult.value = null
        }
    }

    fun clearTestSms() {
        testSmsResult.value = null
    }

    fun commitParsedSms(result: ParsedSmsResult, customNote: String = "") {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val transaction = TransactionEntity(
                title = result.description,
                amount = result.amountToman,
                type = result.type,
                category = result.suggestedCategory,
                bankName = result.bankName,
                cardLast4 = result.cardLast4,
                balanceAfter = result.balanceAfterToman,
                timestamp = now,
                dateStr = PersianUtils.timestampToPersianDate(now),
                trackingCode = result.trackingCode,
                rawSms = result.rawSms,
                note = customNote.ifEmpty { "ثبت دستی از تحلیل پیامک" }
            )
            repository.insertTransaction(transaction)
            testSmsResult.value = null
        }
    }

    fun addManualTransaction(
        title: String,
        amount: Long,
        type: TransactionType,
        category: String,
        bankName: String,
        cardLast4: String,
        note: String
    ) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val transaction = TransactionEntity(
                title = title.ifBlank { if (type == TransactionType.INCOME) "واریز نقدی" else "هزینه نقدی" },
                amount = amount,
                type = type,
                category = category,
                bankName = bankName.ifBlank { "کارت پیش‌فرض" },
                cardLast4 = cardLast4,
                timestamp = now,
                dateStr = PersianUtils.timestampToPersianDate(now),
                note = note
            )
            repository.insertTransaction(transaction)
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun addCard(bankName: String, cardLast4: String, cardHolder: String, initialBalance: Long, colorHex: Long) {
        viewModelScope.launch {
            val card = BankCardEntity(
                bankName = bankName,
                cardLast4 = cardLast4,
                cardHolder = cardHolder.ifBlank { "کارت بانکی" },
                balance = initialBalance,
                colorHex = colorHex
            )
            repository.insertCard(card)
        }
    }

    fun deleteCard(cardId: Long) {
        viewModelScope.launch {
            repository.deleteCard(cardId)
        }
    }

    fun addSender(senderNumber: String, bankName: String, associatedCardLast4: String) {
        viewModelScope.launch {
            val sender = BankSenderEntity(
                senderNumber = senderNumber.trim(),
                bankName = bankName.trim(),
                associatedCardLast4 = associatedCardLast4.trim()
            )
            repository.insertSender(sender)
        }
    }

    fun deleteSender(senderId: Long) {
        viewModelScope.launch {
            repository.deleteSender(senderId)
        }
    }

    fun scanInbox(context: Context) {
        viewModelScope.launch {
            scanStatusMessage.value = "در حال خواندن و تحلیل پیامک‌های بانکی..."
            val count = SmsInboxHelper.scanAndImportBankSms(context, repository)
            scanStatusMessage.value = if (count > 0) {
                "$count پیامک بانکی با موفقیت خوانده و ثبت شد"
            } else {
                "پیامک بانکی جدیدی یافت نشد"
            }
        }
    }

    fun clearScanMessage() {
        scanStatusMessage.value = null
    }
}
