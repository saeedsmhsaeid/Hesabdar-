package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BankCardEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.example.ui.theme.*
import com.example.util.PersianUtils

val CATEGORIES_EXPENSE = listOf(
    "سوپرمارکت", "خوراک و رستوران", "حمل و نقل", "خرید و پوشاک",
    "قبض و ارتباطات", "پزشکی و سلامت", "اقساط و وام", "سایر هزینه‌ها"
)

val CATEGORIES_INCOME = listOf(
    "حقوق و دستمزد", "سود بانکی", "انتقال وجه", "فروش کالا", "سایر درآمدها"
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddTransactionDialog(
    cards: List<BankCardEntity>,
    onDismiss: () -> Unit,
    onConfirm: (title: String, amount: Long, type: TransactionType, category: String, bankName: String, cardLast4: String, note: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var selectedCategory by remember { mutableStateOf(CATEGORIES_EXPENSE[0]) }
    var selectedCardIndex by remember { mutableIntStateOf(0) }
    var note by remember { mutableStateOf("") }

    val categories = if (selectedType == TransactionType.INCOME) CATEGORIES_INCOME else CATEGORIES_EXPENSE

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "ثبت تراکنش جدید",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Type Selector (برداشت / واریز)
                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = selectedType == TransactionType.EXPENSE,
                        onClick = {
                            selectedType = TransactionType.EXPENSE
                            selectedCategory = CATEGORIES_EXPENSE[0]
                        },
                        label = { Text("برداشت / هزینه") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ExpenseRed.copy(alpha = 0.2f),
                            selectedLabelColor = ExpenseRed
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = selectedType == TransactionType.INCOME,
                        onClick = {
                            selectedType = TransactionType.INCOME
                            selectedCategory = CATEGORIES_INCOME[0]
                        },
                        label = { Text("واریز / درآمد") },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IncomeGreen.copy(alpha = 0.2f),
                            selectedLabelColor = IncomeGreen
                        )
                    )
                }

                // Amount
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = PersianUtils.toEnglishDigits(it).filter { ch -> ch.isDigit() } },
                    label = { Text("مبلغ (به تومان)") },
                    supportingText = {
                        val parsed = amountStr.toLongOrNull() ?: 0L
                        if (parsed > 0) {
                            Text(PersianUtils.formatToman(parsed))
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("amount_input"),
                    singleLine = true
                )

                // Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان یا فروشگاه (مثلاً اسنپ یا افق کوروش)") },
                    modifier = Modifier.fillMaxWidth().testTag("title_input"),
                    singleLine = true
                )

                // Card Selection
                if (cards.isNotEmpty()) {
                    Text(
                        text = "انتخاب کارت / حساب:",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        cards.take(3).forEachIndexed { idx, card ->
                            FilterChip(
                                selected = selectedCardIndex == idx,
                                onClick = { selectedCardIndex = idx },
                                label = { Text("${card.bankName} (${PersianUtils.toPersianDigits(card.cardLast4)})") }
                            )
                        }
                    }
                }

                // Category Selection
                Text(
                    text = "دسته‌بندی:",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) }
                        )
                    }
                }

                // Note
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("یادداشت دلخواه") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toLongOrNull() ?: 0L
                    if (amt > 0) {
                        val card = cards.getOrNull(selectedCardIndex)
                        onConfirm(
                            title,
                            amt,
                            selectedType,
                            selectedCategory,
                            card?.bankName ?: "کارت متفرقه",
                            card?.cardLast4 ?: "",
                            note
                        )
                    }
                },
                enabled = (amountStr.toLongOrNull() ?: 0L) > 0,
                modifier = Modifier.testTag("confirm_add_transaction")
            ) {
                Text("ثبت تراکنش")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

@Composable
fun AddCardDialog(
    onDismiss: () -> Unit,
    onConfirm: (bankName: String, cardLast4: String, holder: String, balance: Long, colorHex: Long) -> Unit
) {
    var bankName by remember { mutableStateOf("") }
    var cardLast4 by remember { mutableStateOf("") }
    var holder by remember { mutableStateOf("") }
    var balanceStr by remember { mutableStateOf("") }
    var selectedColor by remember { mutableLongStateOf(CardColorTeal) }

    val presetColors = listOf(CardColorTeal, CardColorMellatRed, CardColorBlu, CardColorGold, CardColorPurple, CardColorSlate)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن کارت بانکی", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = bankName,
                    onValueChange = { bankName = it },
                    label = { Text("نام بانک (مثلاً سامان، ملت، پاسارگاد، بلو)") },
                    modifier = Modifier.fillMaxWidth().testTag("bank_name_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = cardLast4,
                    onValueChange = {
                        val clean = PersianUtils.toEnglishDigits(it).filter { ch -> ch.isDigit() }
                        if (clean.length <= 4) cardLast4 = clean
                    },
                    label = { Text("۴ رقم آخر کارت") },
                    modifier = Modifier.fillMaxWidth().testTag("card_last4_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = holder,
                    onValueChange = { holder = it },
                    label = { Text("نام روی کارت یا کاربرد (مثلاً خرج روزمره)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = balanceStr,
                    onValueChange = { balanceStr = PersianUtils.toEnglishDigits(it).filter { ch -> ch.isDigit() } },
                    label = { Text("موجودی فعلی (به تومان)") },
                    supportingText = {
                        val parsed = balanceStr.toLongOrNull() ?: 0L
                        if (parsed > 0) Text(PersianUtils.formatToman(parsed))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("balance_input"),
                    singleLine = true
                )

                Text("رنگ پس‌زمینه کارت:", style = MaterialTheme.typography.bodyMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    presetColors.forEach { col ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(col))
                                .clickable { selectedColor = col }
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (selectedColor == col) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (bankName.isNotBlank() && cardLast4.isNotBlank()) {
                        onConfirm(
                            bankName,
                            cardLast4,
                            holder,
                            balanceStr.toLongOrNull() ?: 0L,
                            selectedColor
                        )
                    }
                },
                enabled = bankName.isNotBlank() && cardLast4.length >= 2,
                modifier = Modifier.testTag("confirm_add_card")
            ) {
                Text("ذخیره کارت")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun AddSenderDialog(
    onDismiss: () -> Unit,
    onConfirm: (senderNumber: String, bankName: String, cardLast4: String) -> Unit
) {
    var senderNumber by remember { mutableStateOf("") }
    var bankName by remember { mutableStateOf("") }
    var cardLast4 by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن شماره پیامک بانک", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "هر شماره یا نام پیامکی که بانک با آن برای شما پیامک می‌فرستد را وارد کنید تا پیامک‌های آن هدایت و ثبت شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = senderNumber,
                    onValueChange = { senderNumber = it },
                    label = { Text("شماره یا عنوان پیامک (مثال: 9820004000 یا Mellat)") },
                    modifier = Modifier.fillMaxWidth().testTag("sender_number_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = bankName,
                    onValueChange = { bankName = it },
                    label = { Text("نام بانک مربوطه (مثلاً بانک سامان)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = cardLast4,
                    onValueChange = {
                        val clean = PersianUtils.toEnglishDigits(it).filter { ch -> ch.isDigit() }
                        if (clean.length <= 4) cardLast4 = clean
                    },
                    label = { Text("۴ رقم کارت مرتبط (اختیاری)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (senderNumber.isNotBlank()) {
                        onConfirm(
                            senderNumber,
                            bankName.ifBlank { "بانک من" },
                            cardLast4
                        )
                    }
                },
                enabled = senderNumber.isNotBlank(),
                modifier = Modifier.testTag("confirm_add_sender")
            ) {
                Text("ثبت شماره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun TransactionDetailDialog(
    transaction: TransactionEntity,
    onDismiss: () -> Unit,
    onDelete: () -> Unit
) {
    val isExpense = transaction.type == TransactionType.EXPENSE || transaction.type == TransactionType.TRANSFER
    val color = if (isExpense) ExpenseRed else IncomeGreen

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = getCategoryIcon(transaction.category, transaction.type),
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = transaction.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = color.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isExpense) "مبلغ برداشت" else "مبلغ واریز",
                            style = MaterialTheme.typography.bodySmall,
                            color = color
                        )
                        Text(
                            text = PersianUtils.formatToman(transaction.amount),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = color
                            )
                        )
                    }
                }

                DetailRow("نوع تراکنش:", when (transaction.type) {
                    TransactionType.INCOME -> "واریز به حساب"
                    TransactionType.EXPENSE -> "برداشت / خرید"
                    TransactionType.TRANSFER -> "انتقال وجه"
                })

                DetailRow("دسته‌بندی:", transaction.category)
                DetailRow("بانک صادرکننده:", transaction.bankName)
                if (transaction.cardLast4.isNotEmpty()) {
                    DetailRow("شماره کارت:", PersianUtils.toPersianDigits("•••• ${transaction.cardLast4}"))
                }
                if (transaction.balanceAfter != null && transaction.balanceAfter > 0) {
                    DetailRow("مانده پس از تراکنش:", PersianUtils.formatToman(transaction.balanceAfter))
                }
                DetailRow("تاریخ ثبت:", transaction.dateStr)
                if (!transaction.trackingCode.isNullOrEmpty()) {
                    DetailRow("کد رهگیری / مرجع:", PersianUtils.toPersianDigits(transaction.trackingCode))
                }
                if (transaction.note.isNotBlank()) {
                    DetailRow("توضیحات:", transaction.note)
                }

                if (!transaction.rawSms.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "متن خام پیامک بانکی:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = transaction.rawSms,
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("بستن")
            }
        },
        dismissButton = {
            Button(
                onClick = onDelete,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حذف تراکنش")
            }
        }
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
