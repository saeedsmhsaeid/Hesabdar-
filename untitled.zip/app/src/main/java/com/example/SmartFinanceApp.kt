package com.example

import android.app.Application
import com.example.data.db.AppDatabase
import com.example.data.repository.FinanceRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SmartFinanceApp : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { FinanceRepository(database.transactionDao(), database.bankCardDao(), database.bankSenderDao()) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        // Seed default banks and sample data if needed
        applicationScope.launch {
            repository.seedDefaultsIfEmpty()
        }
    }

    companion object {
        lateinit var instance: SmartFinanceApp
            private set
    }
}
