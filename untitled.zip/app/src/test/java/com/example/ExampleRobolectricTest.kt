package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TransactionType
import com.example.sms.PersianBankSmsParser
import com.example.util.PersianUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("حسابدار هوشمند", appName)
    }

    @Test
    fun `test persian bank sms parsing saman`() {
        val sms = """
            برداشت از کارت ۵۸۵۹...۱۲۳۴
            مبلغ: ۱,۵۰۰,۰۰۰ ریال
            مانده: ۱۲,۳۰۰,۰۰۰ ریال
            خرید از فروشگاه افق کوروش
            پیگیری: 87654321
        """.trimIndent()

        val parsed = PersianBankSmsParser.parse(sms, "9820004000")
        assertTrue(parsed.isValidBankSms)
        assertEquals(TransactionType.EXPENSE, parsed.type)
        assertEquals(150000L, parsed.amountToman) // 1,500,000 Rial -> 150,000 Toman
        assertEquals(1230000L, parsed.balanceAfterToman)
        assertEquals("1234", parsed.cardLast4)
        assertEquals("سوپرمارکت", parsed.suggestedCategory)
    }

    @Test
    fun `test persian bank sms parsing income`() {
        val sms = """
            واریز به حساب ...۶۱۰۴
            مبلغ: ۲۵,۰۰۰,۰۰۰ ریال
            مانده: ۴۰,۰۰۰,۰۰۰ ریال
            واریز حقوق ماهانه
        """.trimIndent()

        val parsed = PersianBankSmsParser.parse(sms, "BankMellat")
        assertTrue(parsed.isValidBankSms)
        assertEquals(TransactionType.INCOME, parsed.type)
        assertEquals(2500000L, parsed.amountToman) // 25,000,000 Rial -> 2,500,000 Toman
        assertEquals("حقوق و دستمزد", parsed.suggestedCategory)
    }

    @Test
    fun `test persian digits and toman formatting`() {
        val formatted = PersianUtils.formatToman(150000L)
        assertEquals("۱۵۰,۰۰۰ تومان", formatted)
    }
}
