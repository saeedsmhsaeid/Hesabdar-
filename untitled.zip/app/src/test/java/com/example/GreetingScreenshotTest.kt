package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.example.data.model.BankCardEntity
import com.example.ui.components.BankCardView
import com.example.ui.theme.CardColorTeal
import com.example.ui.theme.SmartFinanceTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GreetingScreenshotTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun greeting_screenshot() {
        val sampleCard = BankCardEntity(
            bankName = "بانک سامان",
            cardLast4 = "5859",
            cardHolder = "کارت شخصی",
            balance = 14500000L,
            colorHex = CardColorTeal
        )
        composeTestRule.setContent {
            SmartFinanceTheme {
                BankCardView(card = sampleCard)
            }
        }

        composeTestRule.onNodeWithText("بانک سامان").assertIsDisplayed()
        composeTestRule.onNodeWithText("کارت شخصی").assertIsDisplayed()
    }
}
